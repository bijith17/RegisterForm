from django.shortcuts import render

# Create your views here.
def Home(request):
    if request.method == 'POST':
        CompanyName=request.POST['CompanyName']
        Industry=request.POST['Industry']
        Description=request.POST['Description']
        CompanyType=request.POST['CompanyType']
        Specialities=request.POST['Specialities']
        CompanySize=request.POST['CompanySize']
        YearFounded=request.POST['YearFounded']
        Workplace=request.POST['Workplace']
        Typicaltime=request.POST['Typicaltime']
        Benefits=request.POST['Benefits']
        CompanyCommitments=request.POST['CompanyCommitments']
        Pincode=request.POST['Pincode']
        Address=request.POST['Address']
        City=request.POST['City']
        State=request.POST['State']
        Landmark=request.POST['Landmark']
        City=request.POST['City']
        City=request.POST['City']
        



    return render(request,'Register1.html')